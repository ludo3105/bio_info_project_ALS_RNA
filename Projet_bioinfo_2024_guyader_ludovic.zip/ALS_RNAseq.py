import pandas as pd
import glob
import re
import xml.etree.ElementTree as et
from typing import Callable
import numpy as np

class ALS_RNAseq:

    def __init__(self, path: str, load_matrix: str | None = None, is_test_data: bool | None = None) -> None:
        if is_test_data is None:
            self.__samples: pd.DataFrame = self.init_sample_annotations(path)
            
            if load_matrix is None:
                self.__data: pd.DataFrame = self.init_data_matrix(path) # data_matrix
            else:
                self.__data: pd.DataFrame = pd.read_csv(load_matrix, index_col=0)
        else:
            self.__samples: pd.DataFrame = self.init_sample_annotations(path, True)
            if load_matrix is None:
                self.__data: pd.DataFrame = self.init_data_matrix(path) # data_matrix
            else:
                self.__data: pd.DataFrame = pd.read_csv(load_matrix, index_col=0)


    def init_data_matrix(self, path: str) -> pd.DataFrame:
        pdList = [] # variable to temporary store all dataframes (one for each txt file)
        # For all txt file (134 files)

        for fname in glob.glob(path + "/*.txt"):
            df = pd.read_table(fname) # put the file in a dataframe

            sample_name = re.search("GSM\d+", fname).group() # type: ignore # search the name of the sample in the file name
            df.rename(index= df["gene/TE"], inplace=True) # type: ignore # rename the index (=rows) using the column containing the gene name
            df.drop(columns=df.columns[0], axis=1, inplace=True) # drop the first column containing the gene name, no more need
            df.rename(columns={ df.columns[0]: sample_name }, inplace = True) # rename the column (there is only one column at this step) using the sample name
            pdList.append(df) # add the current dataframe in the list
            
        data_matrix = pd.concat(pdList, axis=1) # concat all dataframe in 1 dataframe
        return data_matrix.transpose() # transpose the dataframe to get a more standard shape (samples x variables)

    def init_sample_annotations(self, path: str, is_test: bool | None = None) -> pd.DataFrame:
        tags: list[str]
        file: str
        if is_test:
            tags = ["tissue", "diagnosis", "subject id"]
            file = "/GSE122649_family.xml"
        else:
            tags = ["cns subregion", "sample group", "subject id"]
            file = "/GSE124439_family.xml"
        data_annotation = pd.DataFrame(columns = ['Sample_id', 'Cns_subregion', 'sample_group', 'subject_id']) # initialisation of the dataframe
        xtree = et.parse(path + file) # create a variable containing the xml in a tree shape
        xroot = xtree.getroot() # get the root of the tree to start the exploration of the tree/xml
        # for each element named "sample" that can be found from the root
        for child in xroot.iter("{http://www.ncbi.nlm.nih.gov/geo/info/MINiML}Sample"):
            temp_sample_id = child.attrib['iid'] # the attribut of this node contains the sample id ()
            # for each element named "Characteristics" that can be found from the current sample
            for child2 in child.iter("{http://www.ncbi.nlm.nih.gov/geo/info/MINiML}Characteristics"):
                if(child2.attrib["tag"] == tags[0]):
                    temp_cns_subregion = child2.text.replace('\n', '') # type: ignore
                elif(child2.attrib["tag"] == tags[1]):
                    temp_sample_group = child2.text.replace('\n', '') # type: ignore
                    if temp_sample_group == 'sALS      ': temp_sample_group = 'ALS Spectrum MND      '
                    if temp_sample_group == 'sALS/FTD      ': temp_sample_group = 'Other Neurological Disorders      '
                    if temp_sample_group == 'Non-neurological control      ': temp_sample_group = 'Non-Neurological Control      '
                elif(child2.attrib["tag"] == tags[2]):
                    temp_subject_id = child2.text.replace('\n', '') # type: ignore
            temp_df = pd.DataFrame({'Sample_id': [temp_sample_id], 'Cns_subregion': [temp_cns_subregion], 'sample_group': [temp_sample_group], 'subject_id': [temp_subject_id]})
            data_annotation = pd.concat([data_annotation, temp_df])
        return data_annotation


    # -----------------
    # ---- Getters ----
    # -----------------
    
    @property
    def data(self) -> pd.DataFrame:
        return self.__data

    @property
    def samples(self) -> pd.DataFrame:
        return self.__samples
    
    @data.setter
    def data(self, data_matrix: pd.DataFrame) -> None:
        self.__data = data_matrix
        
    @samples.setter
    def samples(self, sample_annotations: pd.DataFrame) -> None:
        self.__samples = sample_annotations

    def get_data_matrix_group_by(self, group_by: str, aggregate: Callable[[np.ndarray], np.ndarray] = np.mean, ax: int | None = None) -> list[pd.DataFrame]:
        l : list = []

        for ele in self.__samples[group_by].unique():
            gsm = np.array(self.__samples[self.__samples[group_by] == ele]['Sample_id'])

            if ax is None:
                l.append((self.__data[self.__data.index.isin(gsm)]))
            else:
                l.append(aggregate(self.__data[self.__data.index.isin(gsm)], axis=ax)) # type: ignore
        return l

    def get_stat(self, ax: int, aggregate: Callable[[np.ndarray], np.ndarray] = np.mean) -> pd.DataFrame:
        """
            aggregate: statistic function to apply on the data_matrix (default : np.mean)
            ax: aggregate per sample: ax=0 | aggregate per gene: ax=1 | full data_matrix: ax=None (Default)
        """
        temp = pd.DataFrame(aggregate(self.__data, axis=ax), columns=[aggregate.__name__]) # type: ignore
        if ax == 0:
            temp.index = self.__data.columns
        else:
            temp.index = self.__data.index
        return temp

    def get_stat_group_by(self, group_by: str, aggregate: Callable[[np.ndarray], np.ndarray] = np.mean, ax:int | None = None) -> list[pd.DataFrame]:
        """
            aggregate: statistic function to apply on the data_matrix (default : np.mean)
            ax: aggregate per sample: ax=0 | aggregate per gene: ax=1 | full data_matrix: ax=None (Default)
        """
        return self.get_data_matrix_group_by(group_by, aggregate=aggregate, ax=ax)

    def get_stat_per_sample(self) -> pd.DataFrame:
        return pd.concat([self.get_stat(1, np.mean), 
                          self.get_stat(1, np.median), 
                          self.get_stat(1, np.std)], axis=1)


    def get_mean_per_gene(self, pd: pd.DataFrame | None = None) -> pd.DataFrame:
        if pd is not None:
            return pd.mean(axis=0).to_frame()
        else:
            return self.__data.mean(axis=0).to_frame()


    def get_description(self) -> dict:
        return {
            "mean": float(self.get_stat(1, np.mean).mean(axis=0)[0]),
            "median": float(self.get_stat(1, np.median).median(axis=0)[0]),
            "std": float(self.get_stat(1, np.std).mean(axis=0)[0])
        }
        
    def get_nbr_of_samples_per_disease_group_and_source(self) -> pd.DataFrame:
        tab : np.ndarray = np.zeros((len(self.__samples['Cns_subregion'].unique()), 4), dtype=int)

        for i, region in enumerate(self.__samples['Cns_subregion'].unique()):
            df_temp = self.__samples[self.__samples['Cns_subregion'] == region]
            
            df_temp_ALS = df_temp[(df_temp['sample_group'] == "ALS Spectrum MND      ")]
            df_temp_no_ALS = df_temp[(df_temp['sample_group'] != "ALS Spectrum MND      ")]
            
            tab[i, 0] = (df_temp_ALS.count())[0]
            tab[i, 1] = len(df_temp_ALS['subject_id'].unique())
            
            # distinct subject_id
            tab[i, 2] = (df_temp_no_ALS.count())[0]
            tab[i, 3] = len(df_temp_no_ALS['subject_id'].unique())

        return pd.DataFrame(tab, 
                    columns=['ALS Spectrum MND', 'ALS Spectrum MND (distinct subject)', 'No ALS', 'No ALS (distinct subject)'],
                    index= list(self.__samples['Cns_subregion'].unique()))

    def __str__(self) -> str:
        return f"RNA_counts: {self.__data}, Sample_annotations: {self.__samples}"